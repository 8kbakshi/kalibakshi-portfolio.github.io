"use client"

import { Button } from "@/components/ui/button"
import { FolderOpen, Linkedin, User } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center py-20 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 left-1/5 w-72 h-48 bg-primary/15 rounded-full blur-3xl opacity-60"></div>
        <div className="absolute bottom-1/3 right-1/6 w-56 h-80 bg-secondary/10 rounded-full blur-2xl opacity-40"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Hey there! I'm <span className="text-primary">Kali Bakshi</span>
          </h1>

          <h2 className="text-xl md:text-2xl text-secondary mb-6">Frontend developer and MCA student</h2>

          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            I'm that person who gets excited about clean code and stays up way too late debugging. Currently grinding
            through my Master's while building cool web apps on the side.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-9">
            <Link href="/about">
              <Button size="lg" className="btn-hover bg-primary hover:bg-primary/90">
                <User className="mr-2 h-4 w-4" />
                More about me
              </Button>
            </Link>
            <Link href="/projects">
              <Button
                variant="outline"
                size="lg"
                className="btn-hover bg-transparent border-secondary text-secondary hover:bg-secondary/10"
              >
                <FolderOpen className="mr-2 h-4 w-4" />
                Check out my work
              </Button>
            </Link>
          </div>

          <div className="flex items-center justify-center space-x-7">
            <a
              href="https://www.linkedin.com/in/kali-bakshi"
              target="_blank"
              rel="noopener noreferrer"
              className="text-muted-foreground hover:text-secondary transition-all duration-300 hover:scale-110"
            >
              <Linkedin size={24} />
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
