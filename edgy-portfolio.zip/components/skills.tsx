import { Card } from "@/components/ui/card"

export function Skills() {
  return (
    <section id="skills" className="py-24 bg-secondary/20">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-bold font-mono text-center mb-16">
            <span className="text-primary">SKILLS</span>
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 bg-card/50 border-border">
              <h3 className="text-2xl font-bold font-mono mb-8 text-center">Frontend Development</h3>
              <div className="space-y-3">
                <div className="text-center">
                  <span className="font-mono text-lg">HTML</span>
                </div>
                <div className="text-center">
                  <span className="font-mono text-lg">CSS</span>
                </div>
                <div className="text-center">
                  <span className="font-mono text-lg">Java</span>
                </div>
                <div className="text-center">
                  <span className="font-mono text-lg">JavaScript</span>
                </div>
              </div>
            </Card>

            <Card className="p-8 bg-card/50 border-border">
              <h3 className="text-2xl font-bold font-mono mb-8 text-center">Backend Systems</h3>
              <div className="space-y-3">
                <div className="text-center">
                  <span className="font-mono text-lg">PHP</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
