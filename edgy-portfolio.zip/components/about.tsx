import { Card } from "@/components/ui/card"
import { Code, GraduationCap, Laptop } from "lucide-react"
import Image from "next/image"

export function About() {
  const services = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "FRONTEND DEVELOPMENT",
      description: "HTML, CSS, Java, JavaScript",
    },
    {
      icon: <Laptop className="w-8 h-8" />,
      title: "BACKEND SYSTEMS",
      description:
        "Proficient in PHP for developing dynamic web applications with backend logic, database integration, and user management",
    },
    {
      icon: <GraduationCap className="w-8 h-8" />,
      title: "CONTINUOUS LEARNING",
      description:
        "Staying aligned with industry trends and continuously upgrading skills in modern software development.",
    },
  ]

  return (
    <section id="about" className="py-24 bg-card/50">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16">
            <span className="text-primary">About me</span>
          </h2>

          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <p className="text-lg text-muted-foreground leading-relaxed">
                I am a motivated Master of Computer Applications (MCA) student, passionate about building innovative web
                applications and scalable backend systems. With strong foundations in both frontend and backend
                development, I focus on creating responsive, user-friendly designs paired with efficient database-driven
                solutions. I enjoy solving real-world problems through technology, writing clean and maintainable code,
                and continuously upgrading my skills to stay aligned with industry trends. My goal is to apply my
                technical expertise to contribute effectively to modern software development projects.
              </p>
            </div>

            <div className="relative ml-4">
              <div className="w-80 h-80 mx-auto rounded-lg overflow-hidden border-4 border-primary/50 shadow-2xl relative transform rotate-1">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20"></div>
                <Image
                  src="/profile-image.jpg"
                  alt="Profile photo"
                  width={320}
                  height={320}
                  className="w-full h-full object-cover relative z-10"
                />
                <div className="absolute inset-0 border-2 border-accent/30 rounded-lg"></div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className={`p-8 bg-card border-primary/30 hover:border-primary transition-all duration-300 group hover:shadow-2xl hover:shadow-primary/20 ${
                  index === 1 ? "mt-4" : ""
                }`}
              >
                <div className="text-primary mb-4 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                <h4 className="text-xl font-bold mb-4 text-secondary">{service.title}</h4>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
