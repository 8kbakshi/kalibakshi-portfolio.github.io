import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"

export function Projects() {
  const projects = [
    {
      title: "Hospital Appointment Website",
      description:
        "A comprehensive hospital management system featuring appointment booking, patient services, and medical department management. Includes navigation for Services, Doctors, Appointments, Emergency Services, and patient feedback with a professional medical interface design.",
      image: "/hospital-website-screenshot.png",
      tags: ["HTML", "CSS", "JavaScript", "PHP"],
      featured: true,
    },
    {
      title: "YouTube Clone",
      description:
        "A static YouTube clone interface built using only HTML and CSS. Features responsive design, clean layout structure, and visual elements that replicate the YouTube user interface without JavaScript functionality.",
      image: "/youtube-clone-screenshot.png",
      tags: ["HTML", "CSS"],
      featured: false,
    },
  ]

  return (
    <section id="projects" className="py-24 bg-card/30">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 glitch neon-glow" data-text="My Projects">
            My <span className="text-primary">Projects</span>
          </h2>

          <div className="grid lg:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <Card
                key={index}
                className="group overflow-hidden bg-card border-primary/30 hover:border-primary transition-all duration-300 hover:shadow-2xl hover:shadow-primary/20"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  {project.title !== "YouTube Clone" && project.title !== "Hospital Appointment Website" && (
                    <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="flex gap-2">
                        <Button size="sm" className="btn-hover bg-primary hover:bg-primary/90">
                          <ExternalLink className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="btn-hover bg-transparent border-secondary text-secondary"
                        >
                          <Github className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold mb-4 text-secondary neon-glow">{project.title}</h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 text-xs bg-primary/20 text-primary rounded border border-primary/30 neon-glow"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  {project.title !== "YouTube Clone" && project.title !== "Hospital Appointment Website" && (
                    <div className="flex gap-4">
                      <Button size="sm" className="btn-hover bg-primary hover:bg-primary/90">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Live Demo
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
