import { Header } from "@/components/header"
import { About } from "@/components/about"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <About />
    </main>
  )
}
